﻿Sample code in Ruby for RChilli Rest api version 8.0.0

Copyright (c) 2019 RChilli Inc. and/or its affiliates. All rights reserved.

This sample code help you to integrate with RChilli Api for resume parsing.
Sample code can be modified and used as per your need.

Sample code file
ParseResume.py : this file can be used to parse the resume on desktop need to convert to base64, you also need to set api credential in this file.



